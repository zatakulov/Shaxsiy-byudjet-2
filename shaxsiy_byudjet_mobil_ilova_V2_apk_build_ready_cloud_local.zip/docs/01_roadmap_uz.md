# Roadmap (amaliy)

## V2 (shu paket)
- Local SQLite CRUD
- Hisobot querylari
- Charts
- Backup/export
- PIN/biometrik gate

## V3
- CBU kursni avtomatik pull (production parser)
- Takrorlanuvchi xarajatlar
- Filter/sort/search
- Batafsil qarz kartochkasi (person history)
- Excel import (migratsiya)

## V4
- Cloud sync
- Ko‘p foydalanuvchi (oila)
- Telegram reminder bot integratsiya (optional)
