# SQL izohlar

- `transactions.amount_uzs` saqlanishi hisobotlarni tezlashtiradi.
- `fx_rates` jadvali USD/UZS kursi tarixini saqlaydi.
- `opening_balances` oy boshidagi qoldiqni hisoblar kesimida saqlaydi.
- `debt_entries` orqali qoldiq hisoblanadi (jamlash).
- `lists_*` jadvallari dinamik dropdownlar uchun ishlatiladi.

Barcha tranzaksiya sanalari:
- `entry_date >= 2026-01-01`
